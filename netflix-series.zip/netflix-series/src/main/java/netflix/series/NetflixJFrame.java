package netflix.series;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;

@SuppressWarnings({ "serial", "unused"})
public class NetflixJFrame extends JFrame {
	
	public ImageIcon icon = new ImageIcon("src/images/netflix-logo.jpg");


	public NetflixJFrame() {
		setTitle("Netflix series");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(400, 300);
		add(new JLabel("JFrame set to center of the screen", SwingConstants.CENTER), BorderLayout.CENTER);
		
	}
	
	public static void main (String[] args) {
	      new NetflixJFrame();
	}
}
